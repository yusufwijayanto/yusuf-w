package com.juaracoding.shopsqa.utils;

public class Constants {
	
	public static final String CHROME ="Chrome";
	public static final String FIREFOX ="Firefox";
	public static final String BROWSER ="browser";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String EMAIL = "email";
	public static final String URL ="https://shop.demoqa.com/";
}
